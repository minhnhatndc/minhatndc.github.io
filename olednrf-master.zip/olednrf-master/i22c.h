/*
 * i22c.h
 *
 *  Created on: 08-Apr-2017
 *      Author: saag
 */

#ifndef EXAMPLES_PERIPHERAL_TWI_SENSOR_I22C_H_
#define EXAMPLES_PERIPHERAL_TWI_SENSOR_I22C_H_



void twi_init(void);


#endif /* EXAMPLES_PERIPHERAL_TWI_SENSOR_I22C_H_ */
