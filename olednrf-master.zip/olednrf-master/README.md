# nRF52-SPI-Master-Demo
nRF52832 SPI/I2C master example with SSD1306 OLED 

# Environment
* nRF52 SDK 0.9.2 or nRF51 SDK 10.0.0
* nRF52-DK
* Seeed OLED Display SSD1306 (128x64)
* Keil MDK 5.16

