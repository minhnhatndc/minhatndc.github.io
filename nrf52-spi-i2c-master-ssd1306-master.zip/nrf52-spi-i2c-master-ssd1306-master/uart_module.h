#ifndef __UART_MODULE_H
#define __UART_MODULE_H

#ifdef __splusplus
extern "C" {
#endif

    void uart_init(void);

#ifdef __splusplus
}
#endif

#endif /* __UART_MODULE_H */

