
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'nrf52-spi-i2c-master-ssd1306' 
 * Target:  'nrf52832_ssd1306' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define GPIOTE_CONFIG_NUM_OF_LOW_POWER_EVENTS
#define GPIOTE_ENABLED
  #define GPIOTE_CONFIG_NUM_OF_LOW_POWER_EVENTS
#define SWI_DISABLE0
#define UART0_ENABLED

#endif /* RTE_COMPONENTS_H */
